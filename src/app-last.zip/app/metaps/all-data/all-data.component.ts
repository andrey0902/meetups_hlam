/**
 * Created by andrei on 08.11.2017.
 */
import { Component, OnInit } from '@angular/core';

@Component({
 selector: 'all-data',
 templateUrl: './all-data.component.html'
})

export class AllDataComponent implements OnInit {
 constructor() { }

 ngOnInit() { }
}
