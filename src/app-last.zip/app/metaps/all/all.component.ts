/**
 * Created by andrei on 08.11.2017.
 */
import { Component, OnInit } from '@angular/core';

@Component({
 selector: 'all',
 templateUrl: './all.component.html'
})

export class AllComponent implements OnInit {
 constructor() { }

 ngOnInit() { }
}
