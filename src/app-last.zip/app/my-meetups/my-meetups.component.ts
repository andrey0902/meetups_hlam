/**
 * Created by andrei on 08.11.2017.
 */
import { Component, OnInit } from '@angular/core';

@Component({
 selector: 'my-meetups',
 templateUrl: './my-meetups.component.html'
})

export class MyMeetupsComponent implements OnInit {
 constructor() { }

 ngOnInit() { }
}
