/**
 * Created by andrei on 08.11.2017.
 */
import { Component, OnInit } from '@angular/core';

@Component({
 selector: 'create-data',
 templateUrl: './create-data.component.html'
})

export class CreateDataComponent implements OnInit {
 constructor() { }

 ngOnInit() { }
}
