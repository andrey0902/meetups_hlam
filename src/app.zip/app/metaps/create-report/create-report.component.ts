/**
 * Created by andrei on 06.11.2017.
 */
import { Component, OnInit } from '@angular/core';
import { MzBaseModal } from 'ng2-materialize';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
 selector: 'create-report',
 templateUrl: './create-report.component.html'
})

export class CreateReportComponent extends MzBaseModal implements OnInit {
  public formCreateReport: FormGroup;
 constructor() {
   super();
 }

 public ngOnInit() {
   this.createForm();
 }
 public createForm() {
   this.formCreateReport = new FormGroup({
     name: new FormControl(null, [
       Validators.required,
       Validators.minLength(3),
       Validators.maxLength(30)
     ])
   });
 }
 public onSubmit(form: FormGroup) {
   if (form.valid) {
     console.log('make to request for create report');
   }
 }
  public resetForm() {
    this.formCreateReport.reset();
  }
}
