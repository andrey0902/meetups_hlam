/**
 * Created by andrei on 06.11.2017.
 */
import { Component, OnInit } from '@angular/core';
import { MzModalService } from 'ng2-materialize';
import { CreateReportComponent } from '../../create-report/create-report.component';
@Component({
 selector: 'modal-button',
 templateUrl: './modal-tregger.component.html'
})

export class ModalTreggerComponent  {
 constructor(private modslService: MzModalService) { }
  public openModal() {
    this.modslService.open(CreateReportComponent);
  }
}
