/**
 * Created by andrei on 05.11.2017.
 */
import { NgModule } from '@angular/core';

import { MetapsComponent } from './metaps.component';
import { RouterModule } from '@angular/router';

@NgModule({
 imports: [RouterModule.forChild([
   {
     path: 'metaps',
     component: MetapsComponent
   }
 ])],
 exports: [RouterModule],
 declarations: [],
 providers: [],
})
export class MetapsRoutingModule { }
